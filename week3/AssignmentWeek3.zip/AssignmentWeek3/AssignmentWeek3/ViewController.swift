//
//  ViewController.swift
//  AssignmentWeek3
//
//  Created by 大容 林 on 2018/2/15.
//  Copyright © 2018年 DjangoCode. All rights reserved.
//

import UIKit
import GameKit

class ViewController: UIViewController {
    var numberArray : [String] = []
    var targetNumber : Int = 0
    var currentNumber : Int = -1
    var currentMaxNumber :Int = 100
    var currentMinNumber : Int = 0
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var enterTextLabel: UILabel!
    
    @IBAction func cancelButtonAction(_ sender: Any) {
        numberArray.removeAll()
        enterTextLabel.text = "請輸入數字"
    }
    @IBAction func sendButtonAction(_ sender: Any) {
       compareWithTarget(enterTextLabel.text!)
    }
    @IBAction func numberAction(_ sender: UIButton) {
        appendDisplayStack(numberString: (sender.titleLabel?.text!)!)
        updateEnterTextLabel(numberArray)
    }
    func appendDisplayStack(numberString :String) {
        numberArray.append(numberString)
    }
    func updateEnterTextLabel(_ numberArray : [String])  {
        if numberArray.count > 0 {
            var finalNumberString : String = ""
            for str in numberArray {
                finalNumberString += str
            }
            enterTextLabel.text = finalNumberString
        }else{
            enterTextLabel.text = "0"
        }
        
    }
    func compareWithTarget(_ enterNumber :  String){
        if let sendNumber = Int(enterNumber){
            if sendNumber == targetNumber {
                currentNumber = sendNumber
            }else if sendNumber > targetNumber {
                currentMaxNumber = sendNumber
            } else {
                currentMinNumber = sendNumber
            }
            displayResult()
        }else {
            enterTextLabel.text = "請輸入數字"
        }
        numberArray.removeAll()
    }
    func displayResult (){
        if currentNumber == targetNumber {
            enterTextLabel.text = "恭喜完成"
        }else{
            enterTextLabel.text = "\(currentMinNumber) ~ \(currentMaxNumber)"
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        targetNumber = GKRandomSource.sharedRandom().nextInt(upperBound: 100)
        titleLabel.text =  String(targetNumber)
        // Do any additional setup after loading the view, typically from a nib.
    }
}

